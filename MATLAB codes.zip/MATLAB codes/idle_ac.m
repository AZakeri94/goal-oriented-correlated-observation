%% suppose action is the idle action, then compute its value
%% Reset of some parameters. Note this is crucial, the code does not work properly otherwise
prob_0 = [];   % _0 stands for the idle action, i.e., a = 0
h_0 = []; 
%%   IDLE ACTION
% # all possible cases = 1
nxt_st_0 = [ st_vcr(1) st_vcr(2)  min(st_vcr(3) + 1, M)  min(st_vcr(4) + 1, M)  ];   % NOTE: _1 stands/indicates the action 1 (i.e., the idle action)
st_indx = find( all( abs(state_space - (nxt_st_0 .* Temp_matrix_)) == 0, 2 ) );
h_0(1) = h( st_indx );
prob_0(1) = 1 ; 

Value_action_0 = C(s_, 1) + sum( prob_0 .* h_0 );