%% This returns the value of sample and transmits the state of Source i

%% Reset of some parameters. Note this is crucial, the code does not work properly otherwise
prob_i = [];
h_i = []; st_indx = [];

%%      sampling od source i

for i = 1 : I

    act = i;

    if i == 1
        P = P_1;
    else
        P = P_2;
    end

     pP = P^st_vcr(i+2);
     w = pP(st_vcr(i), :);

     j = 0;

    for n = 1: N
         
        j = j + 1;

        nxt_st = [ n n 1 1 ];
        st_indx = find( all( abs(state_space - (nxt_st_0 .* Temp_matrix_)) == 0, 2 ) );
        h_i(j) = h( st_indx );
        prob_i (j) = w(n) * q(i) * rho(i);

        %---
        j = j + 1;

        nxt_st = [ n st_vcr(2) 1 min(st_vcr(4)+1, M) ];
        st_indx = find( all( abs(state_space - (nxt_st_0 .* Temp_matrix_)) == 0, 2 ) );
        h_i(j) = h( st_indx );
        prob_i (j) = w(n) * q(i) * (1-rho(i));





    end 


end

%% +++


sP = P ^ state_vector_(4);
v = sP( state_vector_(2) , : ) ;  % probability distribution over the X

if st_vcr(1) >= sm_cst + tr_cst_       % Action 1 is possible if the battery allows doing of joint sampling and (possible) tranmission


    i = 0; % the number of possibilities osfar
    for k = 1: K

        i = i + 1 ;
        next_state_2 = [ min(state_vector_(1) - sm_cst - tr_cst_  + 0, B)  k  k 1 1 ]; % sampled and the sample received
        st_indx(i) = find(all(State_Space - next_state_2 .* Temp_matrix_ == 0, 2));
        h_i(i) = h( st_indx(i) );
        prob_i(i) = (1 - mu) * q *   v(k) ;

        % arrival of energy
        i = i + 1;
        next_state_2 = [ min(state_vector_(1) - sm_cst - tr_cst_  + enr_u, B)  k  k 1 1  ];
        st_indx(i) = find(all(State_Space - next_state_2 .* Temp_matrix_ == 0, 2));
        h_i(i) = h( st_indx(i) );
        prob_i(i) = (mu) * q *   v(k) ;

        % channel effect
        i = i + 1;
        next_state_2 = [ min(state_vector_(1) - sm_cst - tr_cst_  + 0, B) k  state_vector_(3)  1  min(state_vector_(5)+1, M_2) ];
        st_indx(i) = find(all(State_Space - next_state_2 .* Temp_matrix_ == 0, 2));
        h_i(i) = h( st_indx(i) );
        prob_i(i) = (1 - mu) * (1-q) *   v(k) ;

        % channel effect
        i = i + 1;
        next_state_2 = [ min(state_vector_(1) - sm_cst - tr_cst_  + enr_u, B) k  state_vector_(3)  1  min(state_vector_(5)+1, M_2) ];
        st_indx(i) = find(all(State_Space - next_state_2 .* Temp_matrix_ == 0, 2));
        h_i(i) = h( st_indx(i) );
        prob_i(i) = ( mu) * (1-q) *   v(k) ;

    end

    Value_action_3 = c(s_, 4) + sum( prob_i .* h_i );
else
    Value_action_3 = +1e6; % to set a value
end