
st_vcr = state_space(s_, :);

%% Calling dynamic function of each action
idle_ac

src_1_tr_ac 

src_2_tr_ac
%% An optimal action
vector_val = [ Value_action_0, Value_action_1, Value_action_2];
if st_vcr (1, 1) == 0
    optimal_action_ = 1 ;  % the idle action
    
else
    optimal_action_ = find(vector_val == min (vector_val));
    
    if length(optimal_action_) > 1  %|| abs(Value_action_1 - Value_action_2) < 1e-15  % for a numerical issue
        optimal_action_ = optimal_action_(1);
    end
    
end