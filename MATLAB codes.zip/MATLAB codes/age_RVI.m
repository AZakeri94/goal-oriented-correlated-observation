
st_vcr = state_space(s_, :);

%% # the idle action

prob_0 = []; h_0 = [];

nxt_st_0 = [ min(st_vcr(1) + 1, M)  min(st_vcr(2) + 1, M)  ];   % NOTE: _1 stands/indicates the action 1 (i.e., the idle action)
st_indx = find( all( abs(state_space - (nxt_st_0 .* Temp_matrix_)) == 0, 2 ) );
h_0(1) = h( st_indx );
prob_0(1) = 1 ;

Value_action_0 = C(s_, 1) + sum( prob_0 .* h_0 );

%% # the Source 1 tran.
prob_i = [];
h_i = []; 

%---
j = 1;  % a counter for the total number of poss. to next state
nxt_st = [ min(st_vcr(1)+1, M) min(st_vcr(2)+1, M) ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_ )) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = (1-q_1);


j = j + 1;
nxt_st = [ 1 1 ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = q_1 * rho_1;

%---
j = j + 1;
nxt_st = [ 1 min(st_vcr(2)+1, M) ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = q_1 * (1-rho_1);

Value_action_1 = C(s_, 2) + sum( prob_i .* h_i );

%% # the Source 2 tran.
prob_i = [];
h_i = []; 

%---
j = 1;  % a counter for the total number of poss. to next state
nxt_st = [ min(st_vcr(1)+1, M) min(st_vcr(2)+1, M) ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_ )) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = (1-q_2);


j = j + 1;
nxt_st = [ 1 1 ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = q_2 * rho_2;

%---
j = j + 1;
nxt_st = [ min(st_vcr(1)+1, M) 1 ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = q_2 * (1-rho_2);

Value_action_2 = C(s_, 3) + sum( prob_i .* h_i );

%% An optimal action
vector_val = [ Value_action_0, Value_action_1, Value_action_2];
if st_vcr (1, 1) == 0
    optimal_action_ = 1 ;  % the idle action

else
    optimal_action_ = find(vector_val == min (vector_val));

    if length(optimal_action_) > 1  %|| abs(Value_action_1 - Value_action_2) < 1e-15  % for a numerical issue
        optimal_action_ = optimal_action_(1);
    end

end