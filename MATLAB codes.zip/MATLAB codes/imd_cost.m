%% returing the imd. dist. for a given state and action
state_t = s_;
C__i = [];

for i = 1: I   % per-source

    if i == 1
        P = P_1;
    else
        P = P_2;
    end


    pP = P^state_t(i+2);
    w_ = pP(state_t(i), :);  %  the probability distribution over the X from based on available data at the monitor

    %% apply the estimation
    % dis-opt estimate
    for n = 1: N  % per-source
        % er(n) = sum (w .* power([1: N] - (n*ones(1, N)), 2) );  % value of MSE when the estimate is state "k"
        d_i = reshape(rand_cost(i,:,:),N, N);
        er(n) = sum (w_' .* d_i(:, n)  ); % for the distortion
        %                             er(k) = w(k) .* 0 + (sum(w)-w(k)); % for the RTE optimal estimator; equals to the ML estimator
    end
    X_hat = find(min(er) == er);
    X_hat = X_hat(1);
    % ###
    % X_hat = state_t(i);  % last sample estimate
    %---
    d_i = reshape(rand_cost(i,:,:), N, N); % finding per-source dis.
    C__s(i) = sum (w_' .* d_i(:, X_hat)  );  % per-src expected cost

end

action_cost = ones(1, 3);  % action cost
action_cost(1) = 0;
C__i = sum (W .* C__s) + alpha .* action_cost  ;

% per-source weighted distortion
C_srcdis = W .* C__s;

