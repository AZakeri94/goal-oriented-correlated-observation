disp( " the emprical policy evaluation is running ... " )
Num_itr_ = 1e5;
Num_epochs_ = 1;
%% loop and pre-allocation of some parameters
imd_cst =  zeros (Num_itr_, Num_epochs_);

for epoch_itr_ = 1 : Num_epochs_
    %% initialization
    s_ = [ 1, 1, 1, 1 ];  %  [  X_1 X_2 theta_1 theta_2   ]
    %     disp( ['episode #', num2str(epoch_itr_)])
    s_age = [ 1 1 ];  % for age-optimal baseline! for the dis. optimal policy "s_" should be uncommented


    for itr_cntr_ = 1 : Num_itr_

        %% Finding the corresponding action
        % st_indx = find( all( abs((state_space - s_) .* Temp_matrix_) == 0, 2)); % comment this when evaluting the age-optimal policy
        % action_ = Q_state_action(st_indx);
        % % 
         % st_indx = find( all( abs((state_space - s_age) .* Temp_matrix_) == 0, 2)); % for performance of age-optimal policy
         % action_ = Q_state_action(st_indx);  % finding the action through the Q table

        %% A baseline policy: min-cost, i.e., command the sensor who has lower cost
        % imd_cost; % to calculate dis. cost for age-optimal policy
        % act_tmp = find( min(C_srcdis) == C_srcdis );
        % action_ = act_tmp(1);


        %%         A baseline policy, i.e., max-age policy
        % age = [s_(3) s_(4)];
        % action_tmp = find( max(age) == age );
        % action_ = action_tmp(1) + 1;  % since "action = 1" is the idle action

        %% high probable policy
        if q_1 * rho_1 >= q_2 * rho_2 
            action_ = 1 ;
        else 
            action_ = 2 ;
        end

        %% Updating the current state vector under the action and system dynamic

        chnl_succ_rlz_1 = randsrc(1, 1, [[1 0]; [q_1  1 - q_1]]);
        chnl_succ_rlz_2 = randsrc(1, 1, [[1 0]; [q_2  1 - q_2]]);
        chnl_succ = [ chnl_succ_rlz_1 chnl_succ_rlz_2];

        rho_1_rl = randsrc(1, 1, [[1 0]; [rho_1  1 - rho_1]]);
        rho_1_r2 = randsrc(1, 1, [[1 0]; [rho_2  1 - rho_2]]);
        rho_rlz = [ rho_1_rl rho_1_r2 ];

        %--- gener. state of sources according to beleif
        pP = P_1^s_(3);  % source 1
        w_1 = pP(s_(1), :);
        nx_X1 = randsrc(1, 1, [[1:N]; w_1]);

        pP = P_2^s_(4);   % source 2
        w_2 = pP(s_(2), :);
        nx_X2 = randsrc(1, 1, [[1:N]; w_2]);

        %% per-action dynamic

        imd_cost; % to calculate dis. cost for age-optimal policy

        if action_ == 1

            nxt_s = [ s_(1) s_(2) min(s_(3)+1, M) min(s_(4)+1, M) ];
            % imd_cst(itr_cntr_, epoch_itr_) = C(st_indx, 1);
            imd_cst(itr_cntr_, epoch_itr_) = C__i(1); % this is for age-optimal policy

        elseif action_ == 2  % trsn. Src 1

            if chnl_succ(1) == 1

                if rho_rlz(1) == 1
                    nxt_s = [ nx_X1 nx_X2 1 1];
                else
                    nxt_s = [ nx_X1, s_(2), 1 min(s_(4)+1, M)];
                end

            else
                nxt_s = [ s_(1), s_(2), min(s_(3)+1, M), min(s_(4)+1, M) ];
            end

            % imd_cst(itr_cntr_, epoch_itr_) = C(st_indx, 2);
            imd_cst(itr_cntr_, epoch_itr_) = C__i(2);


        elseif action_ == 3

            if chnl_succ(2) == 1

                if rho_rlz(2) == 1
                    nxt_s = [ nx_X1 nx_X2 1 1];
                else
                    nxt_s = [s_(1), nx_X2, min(s_(3)+1, M), 1];
                end

            else
                nxt_s = [ s_(1), s_(2), min(s_(3)+1, M), min(s_(4)+1, M)];
            end

            % imd_cst(itr_cntr_, epoch_itr_) = C(st_indx, 3);
            imd_cst(itr_cntr_, epoch_itr_) = C__i(3);

        end

        s_ = nxt_s;
        s_age = [ nxt_s(3) nxt_s(4) ];

    end
end

empr_prf = mean(mean( imd_cst )) ;
% disp(['emprical performance = ' , num2str(empr_prf) ])

