%% ********************
%% Remote Tracking of binary correlated sources
%%
%% ****************
%%

% clc
% clear all
close all

%% per-source setup
I = 2; % number of sources
N = 2; % the number of source's state
w_1 = 1; w_2 = 1; % the weight of source_i
W = [w_1 w_2];  % weights in vector
alpha = .5; % the coneff in the objective function
m = 1; l = 1;
ageopt_disempr  = zeros(1, 15); prf_valref  = zeros(1, 15); % memory allocation

for rho_1 = 0: 0.2 : 1
    % for rho_1 = 0:0.1:1 
    p_1 = 0.9; %p_2 = 0.9; % source dynamic
    p_2 = p_1;

    P_1 = [ p_1 1-p_1 ; 1-p_1 p_1];
    P_2 = [ p_2 1-p_2 ; 1-p_2 p_2];
    

    % rho_1 = 0.4; 
    rho_2 = rho_1; % 0.7; % correlation factors; rho_1 is equavalent of rho_12 in the manus.
    
    q_1 = 0.9;
    q_2 = 0.9; 

    %% Sys.  Parameters
    M = 50; % the aoi bound at the sink

    %%  state space and action space
    Action_S = 3;   % Action space   {1 (idle), action = i means commanding sensor i-1}
    state_dim = I ;

    %% Generating the  (beleif) state space
    sta_cntr = 0;
    state_space =  zeros( N * M * I * 100, state_dim);
    C = []; % this reset is mandatory when it is over a for loop of a parameter
    for aoi_1 = 1: M
        for aoi_2 = 1: M

            sta_cntr = sta_cntr + 1;
            state_t = [ aoi_1 aoi_2 ];
            state_space(sta_cntr, :) = state_t;
            C(sta_cntr,1) = sum (W .* state_t);  % sum weighted ages as the imidiate cost

        end
    end


    st_num = sta_cntr ;
    state_space = state_space(1: st_num, :);
    Temp_matrix_ = ones(st_num, state_dim);

    % The immidiate cost function, weght. age + trans. cost
    C = C(1 : st_num, :,:,:);
    C = C * ones(1, Action_S);
    tmp = ones(st_num, Action_S);
    tmp(:,1) = 0;
    C = C + alpha .* tmp; % cost of state and action

    %% +++ below is not modified

    %% RVI algorihtm
    % Initialization
    h = zeros(st_num, 1);
    h_temp = 50 * ones(st_num, 1);
    Val_s_ = zeros(st_num, 1);
    Q_state_action = ones(st_num, 1); % per-state optimal action

    % Accuracy and other related paramteres
    Epsilon_h = 1e-3;
    ref_indx = 1;
    rvi_cntr_ = 0; % Flag to stop the RVI's main loop
    n = 0 ; V_ref = 0; % Alternative to control the STOP
    N_max = 2*1e3; Val_record = zeros(1, N_max); %vector_val_save = zeros(total_num_state_, Action_S);
    %%
    while rvi_cntr_ == 0  % for the convergence of RVI
        %% Loop over the state space   Note: it seems that this cannot be implemented by PARFOR due to some dependences
        for s_ = 1 : st_num

            age_RVI	; % a^* = argmin of the Bellman equation ...
            Val_s_(s_) = vector_val(optimal_action_);
            V_ref = Val_s_( ref_indx );
            h_temp (s_ ) = Val_s_(s_) - V_ref;
            Q_state_action(s_ , :) = optimal_action_;
            %vector_val_save(s_ , :) =  vector_val ;

        end

        %% Updates
        h_old = h;
        h = h_temp;
        n = n + 1;
        %% Convergence condition
        if   n > N_max  ||  max(abs(h_old - h)) < Epsilon_h
            rvi_cntr_ = 1;
        end
        %         Val_record(n) = V_ref;
    end

    % disp( vpa(V_ref)  )
    %     find( Q_state_action == 3)  % wether the "just sample" action has been taken
    %         disp( [State_Space, Q_state_action])
    %     disp([ "the convergence iteration number is", num2str(n) ] )
    %% Policy evaluation
    emprical_performance_evaluation
    %% FOR THE MAIN LOOP
    %     disp([ 'the value of s_ref = ', num2str(V_ref) ] )
    prf_valref (m,l) = V_ref;
    ageopt_disempr(m,l) = empr_prf;
    l = l + 1;
    % end
m = m + 1;
l = 1;
end 
toc
%%  print the results

disp([ 'the emprical prf  = ', num2str( ageopt_disempr ) ])


%% Code for the switcing type structure for a fixed value of the AoI at the
% trabsnitter, i.e., theta

% X_tile = 1; X_hat = 0;
%
% figure
% for b = 0: B
%     for n = 1: N
%         if Q_state_action( ismember(State_Space, [ b,  n, X_tile, X_hat ], 'rows') ) == 3
%             p_2=plot(b,n,'MarkerFaceColor',[0.39,0.83,0.07],'MarkerSize',5,'Marker','o',...
%                 'LineWidth',1.5,...
%                 'Color',[0.39,0.83,0.07]);
%             hold on
%
%         elseif Q_state_action( ismember(State_Space, [ b,  n, X_tile, X_hat ], 'rows') ) == 2
%             p_2=plot(b,n,'MarkerFaceColor',[ 0, 0, 1 ],'MarkerSize',5,'Marker','square',...
%                 'LineWidth',1.5,...
%                 'Color',[0, 0, 1 ]);
%             hold on
%         elseif Q_state_action( ismember(State_Space, [ b,  n, X_tile, X_hat ], 'rows')) == 1
%
%             p_1=plot(b,n,'MarkerFaceColor',[1 0 0],'MarkerSize',9,'Marker','x',...
%                 'LineWidth',2,...
%                 'Color',[1 0 0]);
%             hold on
%         end
%
%     end
% end

% title( num2str(X_tile), num2str(X_hat) )





