%% This returns the value of sample and transmits the state of Source 1

%% Reset of some parameters. Note this is crucial, the code does not work properly otherwise
prob_i = [];
h_i = []; st_indx = [];

%%      sampling od source i

P = P_2;

pP = P^st_vcr(1+2);
w_1 = pP(st_vcr(1), :);  % prob. dis. of X_1(t)

pP = P_2^st_vcr(4);
w_2 = pP(st_vcr(2), :);  % prob. dis. of X_2(t)




%---
j = 1;  % a counter for the total number of poss. to next state
nxt_st = [ st_vcr(1) st_vcr(2) min(st_vcr(3)+1, M) min(st_vcr(4)+1, M) ];
st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_ )) == 0, 2 ) );
h_i(j) = h( st_indx );
prob_i(j) = (1-q_2);

for n_2 = 1: N

    for n_1 = 1: N  % for Source 2

    j = j + 1;

    nxt_st = [ n_1 n_2 1 1 ];
    st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
    h_i(j) = h( st_indx );
    prob_i(j) = w_1(n_1) * w_2(n_2) * q_2 * rho_2;

    end

    %---
    j = j + 1;

    nxt_st = [ st_vcr(1) n_2 min(st_vcr(3)+1, M) 1 ];
    st_indx = find( all( abs(state_space - (nxt_st .* Temp_matrix_)) == 0, 2 ) );
    h_i(j) = h( st_indx );
    prob_i(j) = w_2(n_2) * q_2 * (1-rho_2);


end

Value_action_2 = C(s_, 3) + sum( prob_i .* h_i );

